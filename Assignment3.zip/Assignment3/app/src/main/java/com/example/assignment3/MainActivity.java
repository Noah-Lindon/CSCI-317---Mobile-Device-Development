package com.example.assignment3;

import android.app.Activity;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;


public class MainActivity extends Activity
implements TextView.OnEditorActionListener {

    private EditText fahrenheit_amount;
    private TextView celsius_amount;
    private SharedPreferences savedValues;
    private String fahrenheitString;
    private String celsiusString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fahrenheit_amount = (EditText) findViewById(R.id.fahrenheit_amount);
        celsius_amount = (TextView)findViewById(R.id.celsius_amount);
        fahrenheit_amount.setOnEditorActionListener(this);
        savedValues = getSharedPreferences("SavedValue", MODE_PRIVATE );
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        fahrenheitString = fahrenheit_amount.getText().toString();

        float fahrenheit;

        if (fahrenheitString.equals("")) {
            fahrenheit = 0;
        }
        else {
            fahrenheit = Float.parseFloat(fahrenheitString);
        }

        float celsius = (fahrenheit - 32) * 5/9;

        // Display the results
        NumberFormat number = NumberFormat.getNumberInstance();
        celsiusString = number.format(celsius);
        celsius_amount.setText(celsiusString);

        return false;
    }

    @Override
    public void onPause() {
        SharedPreferences.Editor editor = savedValues.edit();
        editor.putString("fahrenheitString", fahrenheitString);
        editor.putString("celsiusString", celsiusString);
        editor.commit();

        super.onPause();
    }

    @Override
    public void onResume(){
        super.onResume();

        // Get the string
        fahrenheitString = savedValues.getString("fahrenheitString", "");
        celsiusString = savedValues.getString("celsiusString", "");

        fahrenheit_amount.setText(fahrenheitString);
        celsius_amount.setText(celsiusString);
    }
}
